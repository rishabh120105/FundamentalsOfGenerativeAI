
import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Github, Twitter, Linkedin, ShieldCheck, LineChart } from 'lucide-react';

const Footer: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const scrollToSection = (id: string) => {
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById(id);
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-slate-950 border-t border-slate-900 py-16 px-4">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <LineChart className="w-6 h-6 text-indigo-500" />
            <span className="text-lg font-bold">AlphaSight</span>
          </div>
          <p className="text-slate-400 text-sm leading-relaxed">
            Institutional-grade algorithmic trading platform for professional traders. Powered by next-gen AI and low-latency infrastructure.
          </p>
          <div className="flex space-x-4">
            <Twitter className="w-5 h-5 text-slate-500 hover:text-white cursor-pointer transition-colors" />
            <Github className="w-5 h-5 text-slate-500 hover:text-white cursor-pointer transition-colors" />
            <Linkedin className="w-5 h-5 text-slate-500 hover:text-white cursor-pointer transition-colors" />
          </div>
        </div>

        <div>
          <h4 className="font-bold text-white mb-6">Product</h4>
          <ul className="space-y-4 text-slate-400 text-sm">
            <li><button onClick={() => scrollToSection('market')} className="hover:text-white transition-colors">Market Intelligence</button></li>
            <li><button onClick={() => scrollToSection('features')} className="hover:text-white transition-colors">Strategy Builder</button></li>
            <li><Link to="/admin" className="hover:text-white transition-colors">Platform Access</Link></li>
            <li><Link to="/admin" className="hover:text-white transition-colors">API Keys</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white mb-6">Resources</h4>
          <ul className="space-y-4 text-slate-400 text-sm">
            <li><button onClick={() => scrollToSection('how-it-works')} className="hover:text-white transition-colors">How it Works</button></li>
            <li><Link to="/admin" className="hover:text-white transition-colors">Webinars</Link></li>
            <li><Link to="/admin" className="hover:text-white transition-colors">Security Docs</Link></li>
            <li><Link to="/admin" className="hover:text-white transition-colors">Affiliate Program</Link></li>
          </ul>
        </div>

        <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-800">
          <h4 className="font-bold text-white mb-4 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-500" />
            Security First
          </h4>
          <p className="text-slate-400 text-xs leading-relaxed">
            AlphaSight is encrypted with SOC2 Level 3 standards. We never store your broker credentials on our servers.
          </p>
          <div className="mt-4 flex gap-2">
            <div className="w-8 h-8 bg-white/5 rounded flex items-center justify-center text-[10px] font-bold text-slate-500">PCI</div>
            <div className="w-8 h-8 bg-white/5 rounded flex items-center justify-center text-[10px] font-bold text-slate-500">SOC2</div>
            <div className="w-8 h-8 bg-white/5 rounded flex items-center justify-center text-[10px] font-bold text-slate-500">GDPR</div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-slate-900">
        <div className="bg-slate-900/30 p-4 rounded-lg mb-8">
          <p className="text-slate-500 text-[10px] leading-relaxed uppercase tracking-wider font-bold mb-2">Legal Disclaimer</p>
          <p className="text-slate-600 text-[11px] leading-relaxed">
            Trading stocks, options, and futures involves substantial risk and is not suitable for every investor. The valuation of financial instruments may fluctuate, and as a result, clients may lose more than their original investment. AlphaSight is a platform providing data and automation tools and does not provide financial advice. Past performance is not indicative of future results. Information is provided 'as is' and solely for informational purposes, not for trading purposes or advice.
          </p>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500 text-xs">
          <p>&copy; 2024 AlphaSight Technologies Inc. All Rights Reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Risk Disclosure</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
