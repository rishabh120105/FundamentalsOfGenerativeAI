
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  LayoutDashboard, 
  BarChart3, 
  Newspaper, 
  Users, 
  CreditCard, 
  Settings, 
  Bell, 
  Search,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Box,
  Cpu,
  ShieldCheck,
  ChevronDown,
  Power,
  Sparkles,
  FileText,
  Calendar,
  Globe,
  Lock,
  Zap,
  CheckCircle2,
  AlertTriangle,
  X,
  ArrowRight,
  Loader2,
  User,
  LogOut,
  Command,
  Target
} from 'lucide-react';
import AdvancedChart from '../components/AdvancedChart';
import SentimentAnalysis from '../components/SentimentAnalysis';
import OnboardingFlow from '../components/OnboardingFlow';
import { TICKER_DATA, NEWS_CMS_DATA, PRICING_TIERS } from '../constants';
import { AdminView, NewsItem } from '../types';

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [activeView, setActiveView] = useState<AdminView>('dashboard');
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  
  // Local functional states
  const [articles, setArticles] = useState<NewsItem[]>(NEWS_CMS_DATA);
  const [riskWarning, setRiskWarning] = useState("Trading stocks, options, and futures involves substantial risk and is not suitable for every investor. The valuation of financial instruments may fluctuate, and as a result, clients may lose more than their original investment.");
  const [isSaving, setIsSaving] = useState(false);
  const [showToast, setShowToast] = useState(false);

  // Trade form states
  const [tradeSymbol, setTradeSymbol] = useState('NVDA');
  const [tradeSide, setTradeSide] = useState<'BUY' | 'SELL'>('BUY');
  const [tradeQty, setTradeQty] = useState('10');

  // Search Logic
  const filteredResults = useMemo(() => {
    if (!searchQuery.trim()) return { markets: [], news: [], views: [] };
    const q = searchQuery.toLowerCase();
    
    return {
      markets: TICKER_DATA.filter(s => s.symbol.toLowerCase().includes(q)),
      news: articles.filter(a => a.title.toLowerCase().includes(q)),
      views: [
        { id: 'dashboard', label: 'Analytics Hub' },
        { id: 'cms', label: 'Market Intelligence CMS' },
        { id: 'subscriptions', label: 'Billing & Tiers' },
        { id: 'leads', label: 'User Management' },
        { id: 'settings', label: 'System Settings' }
      ].filter(v => v.label.toLowerCase().includes(q))
    };
  }, [searchQuery, articles]);

  const hasAnyResults = filteredResults.markets.length > 0 || filteredResults.news.length > 0 || filteredResults.views.length > 0;

  useEffect(() => {
    const visited = localStorage.getItem('alphasight_visited');
    if (!visited) {
      setShowOnboarding(true);
      localStorage.setItem('alphasight_visited', 'true');
    }

    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleCreateReport = () => {
    const newArticle: NewsItem = {
      id: Math.random().toString(),
      title: "New Market Strategy: " + TICKER_DATA[Math.floor(Math.random()*TICKER_DATA.length)].symbol + " Breakout",
      category: 'Market',
      timestamp: 'Just now',
      author: 'Admin',
      summary: 'Automated technical breakout report based on RSI-14 divergence.'
    };
    setArticles([newArticle, ...articles]);
    triggerToast();
  };

  const handleExecuteTrade = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setIsTradeModalOpen(false);
      triggerToast();
    }, 1500);
  };

  const handleSaveSettings = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      triggerToast();
    }, 1000);
  };

  const triggerToast = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const menuItems = [
    { id: 'dashboard', icon: <LayoutDashboard size={20} />, label: 'Analytics Hub' },
    { id: 'cms', icon: <Newspaper size={20} />, label: 'Market Intelligence' },
    { id: 'subscriptions', icon: <CreditCard size={20} />, label: 'Billing & Tiers' },
    { id: 'leads', icon: <Users size={20} />, label: 'User Management' },
    { id: 'settings', icon: <Settings size={20} />, label: 'System Settings' }
  ];

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* AI Mood Banner */}
      <div className="bg-gradient-to-r from-indigo-900/40 via-slate-900 to-emerald-900/40 border border-indigo-500/20 p-4 rounded-2xl flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="bg-indigo-600 p-2 rounded-lg shadow-lg shadow-indigo-600/20">
            <Sparkles className="text-white" size={18} />
          </div>
          <div>
            <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">Market Mood Summary</div>
            <div className="text-sm text-slate-200 font-medium">AI indicates a <span className="text-emerald-400 font-bold">Strong Bullish</span> trend across Tech sectors. QQQ sentiment is at 0.84.</div>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setActiveView('cms')}
            className="text-xs text-indigo-400 font-bold hover:text-indigo-300 transition-colors bg-indigo-500/10 px-3 py-1.5 rounded-lg border border-indigo-500/20"
          >
            View AI Reports
          </button>
          <button 
            onClick={() => { setTradeSide('BUY'); setTradeSymbol('NVDA'); setIsTradeModalOpen(true); }}
            className="text-xs text-emerald-400 font-bold hover:text-emerald-300 transition-colors bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20 flex items-center gap-1"
          >
            <Zap size={12}/> Execute Signal
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { label: 'Portfolio Value', value: '$242,504.12', delta: '+4.2%', icon: <Box className="text-indigo-400"/> },
              { label: 'Active Capital', value: '$84,102.00', delta: '+12.1%', icon: <Cpu className="text-emerald-400"/> },
              { label: 'Risk Exposure', value: 'Low (0.12)', delta: '-2.4%', icon: <ShieldCheck className="text-amber-400"/> }
            ].map((stat, i) => (
              <div key={i} className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl hover:border-slate-700 transition-all group">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-slate-950 rounded-lg group-hover:scale-110 transition-transform">{stat.icon}</div>
                  <span className={`text-xs font-bold px-2 py-1 rounded-md ${stat.delta.startsWith('+') ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                    {stat.delta}
                  </span>
                </div>
                <div className="text-2xl font-bold text-white mb-1 font-mono">{stat.value}</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="h-[500px]">
            <AdvancedChart />
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-white">Execution Logs</h3>
              <button className="text-indigo-400 text-xs font-bold hover:underline">View History</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-950/50">
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Type</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Symbol</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Price</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Size</th>
                    <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {[
                    { type: 'BUY', sym: 'NVDA', price: '822.45', size: '15', status: 'FILLED' },
                    { type: 'SELL', sym: 'TSLA', price: '169.10', size: '100', status: 'FILLED' },
                    { type: 'BUY', sym: 'BTC', price: '68,122.00', size: '0.5', status: 'PENDING' }
                  ].map((order, i) => (
                    <tr key={i} className="hover:bg-slate-800/30 transition-colors">
                      <td className={`px-6 py-4 text-xs font-bold ${order.type === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}`}>{order.type}</td>
                      <td className="px-6 py-4 text-xs font-bold text-white">{order.sym}</td>
                      <td className="px-6 py-4 text-xs font-mono text-slate-400">${order.price}</td>
                      <td className="px-6 py-4 text-xs font-mono text-slate-400">{order.size}</td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${order.status === 'FILLED' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>
                          {order.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <SentimentAnalysis />
          
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden group">
            <div className="absolute -right-4 -bottom-4 opacity-10 group-hover:scale-125 transition-transform duration-500">
              <Cpu size={120} />
            </div>
            <h4 className="text-lg font-bold mb-2">Pro Data Active</h4>
            <p className="text-indigo-100 text-xs leading-relaxed mb-6 opacity-80">
              You are currently using Institutional level API access. 99.9% market coverage.
            </p>
            <button 
              onClick={() => setActiveView('subscriptions')}
              className="w-full bg-white/20 backdrop-blur-md border border-white/30 text-white py-3 rounded-xl font-bold text-xs hover:bg-white/30 transition-all"
            >
              Manage Access
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCMS = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Market Intelligence CMS</h2>
          <p className="text-slate-400">Manage daily analysis, stock reports, and community alerts.</p>
        </div>
        <button 
          onClick={handleCreateReport}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-indigo-600/20"
        >
          <Plus size={20} /> Create New Report
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/30">
              <h3 className="font-bold text-white flex items-center gap-2"><FileText size={18} className="text-indigo-400"/> Published Articles</h3>
              <div className="flex gap-2">
                <button className="px-3 py-1 bg-slate-950 rounded text-xs text-slate-400 font-bold border border-slate-800">All</button>
                <button className="px-3 py-1 bg-indigo-600/10 rounded text-xs text-indigo-400 font-bold border border-indigo-500/20">Market</button>
                <button className="px-3 py-1 bg-slate-950 rounded text-xs text-slate-400 font-bold border border-slate-800">Macro</button>
              </div>
            </div>
            <div className="divide-y divide-slate-800">
              {articles.map(news => (
                <div key={news.id} className="p-6 flex items-start justify-between hover:bg-slate-800/30 transition-colors">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-slate-800 rounded-lg flex items-center justify-center font-bold text-slate-500 uppercase">
                      {news.category[0]}
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-1">{news.title}</h4>
                      <p className="text-xs text-slate-500 mb-2">{news.author} • {news.timestamp}</p>
                      <div className="flex gap-2">
                        <span className="px-2 py-0.5 bg-slate-950 text-slate-500 rounded text-[10px] font-bold uppercase tracking-wider">{news.category}</span>
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-500 rounded text-[10px] font-bold uppercase tracking-wider">Live</span>
                      </div>
                    </div>
                  </div>
                  <button className="text-slate-500 hover:text-white font-bold text-xs p-2">Edit</button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
            <h3 className="font-bold text-white mb-6 flex items-center gap-2"><Calendar size={18} className="text-indigo-400"/> Earnings Calendar</h3>
            <div className="space-y-4">
              {[
                { ticker: 'NVDA', date: 'Tomorrow, BMO', type: 'High Impact' },
                { ticker: 'MSFT', date: 'May 24, AMC', type: 'Normal' },
                { ticker: 'AAPL', date: 'May 28, AMC', type: 'High Impact' }
              ].map((item, i) => (
                <div key={i} className="flex justify-between items-center p-3 bg-slate-950 rounded-xl border border-slate-800 group hover:border-indigo-500/50 transition-all cursor-pointer">
                  <div>
                    <div className="text-xs font-bold text-white">{item.ticker}</div>
                    <div className="text-[10px] text-slate-500">{item.date}</div>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${item.type === 'High Impact' ? 'bg-rose-500/10 text-rose-500' : 'bg-slate-800 text-slate-400'}`}>
                    {item.type}
                  </span>
                </div>
              ))}
            </div>
            <button className="w-full mt-6 py-3 border border-slate-800 text-slate-400 text-xs font-bold rounded-xl hover:bg-slate-800 transition-all">Manage Calendar</button>
          </div>

          <div className="bg-gradient-to-br from-slate-900 to-indigo-900/50 border border-slate-800 p-6 rounded-2xl shadow-xl relative overflow-hidden group">
            <Sparkles className="absolute -top-4 -right-4 w-24 h-24 opacity-5 group-hover:scale-110 transition-transform" />
            <h3 className="font-bold text-white mb-2">Stock of the Week</h3>
            <p className="text-xs text-slate-400 mb-6">Current: <span className="text-indigo-400 font-bold">NVDA</span>. Select next candidate for publishing.</p>
            <button className="w-full py-3 bg-indigo-600 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all">Open Candidate List</button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSubscriptions = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Billing & Revenue</h2>
          <p className="text-slate-400">Monitor subscriptions, MRR growth, and tier distributions.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-slate-900 border border-slate-800 text-white px-4 py-3 rounded-xl font-bold text-sm flex items-center gap-2 hover:bg-slate-800 transition-all">
            Export Data
          </button>
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-indigo-600/20">
            Edit Pricing Tiers
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Current MRR', value: '$84,120', delta: '+8.4%', color: 'text-indigo-400' },
          { label: 'Active Subs', value: '1,242', delta: '+2.1%', color: 'text-emerald-400' },
          { label: 'Churn Rate', value: '0.8%', delta: '-1.4%', color: 'text-emerald-500' },
          { label: 'Avg LTV', value: '$1,204', delta: '+4.2%', color: 'text-amber-400' }
        ].map((stat, i) => (
          <div key={i} className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
            <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-2">{stat.label}</div>
            <div className="text-2xl font-bold text-white mb-1 font-mono">{stat.value}</div>
            <div className={`text-xs font-bold ${stat.delta.startsWith('+') ? 'text-emerald-500' : 'text-rose-500'}`}>{stat.delta} <span className="text-slate-500 font-normal">vs last month</span></div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {PRICING_TIERS.map(tier => (
          <div key={tier.id} className="bg-slate-900 border border-slate-800 p-8 rounded-3xl relative overflow-hidden group hover:border-indigo-500/50 transition-all">
            {tier.isPopular && <div className="absolute top-0 right-0 bg-indigo-600 px-4 py-1 text-[10px] font-bold text-white rounded-bl-xl uppercase tracking-widest">Active Tier</div>}
            <h3 className="text-2xl font-bold text-white mb-1">{tier.name}</h3>
            <div className="text-xs text-slate-500 mb-6">{tier.price} {tier.period}</div>
            <div className="space-y-4 mb-8">
              {tier.features.slice(0, 3).map((f, i) => (
                <div key={i} className="flex items-center gap-3 text-xs text-slate-400">
                  <CheckCircle2 size={14} className="text-emerald-500" /> {f}
                </div>
              ))}
            </div>
            <div className="flex justify-between items-center pt-6 border-t border-slate-800">
              <div className="text-xs font-bold text-white">412 Users</div>
              <button 
                onClick={() => setActiveView('leads')}
                className="text-indigo-400 text-xs font-bold hover:underline"
              >
                Manage Subscribers
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderLeads = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">User Management</h2>
          <p className="text-slate-400">Manage traders, view newsletter leads, and affiliate status.</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
            <input 
              type="text" 
              placeholder="Filter by email or ticker..." 
              className="bg-slate-900 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-sm w-64 focus:outline-none focus:border-indigo-500 transition-all"
            />
          </div>
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-all">
            Add New User
          </button>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/30">
          <h3 className="font-bold text-white flex items-center gap-2"><Users size={18} className="text-indigo-400"/> Registered Traders</h3>
          <span className="text-xs text-slate-500">Showing 1-10 of 12,422</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-950/50">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">User</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Tier</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Broker</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Last Activity</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {[
                { name: 'Sarah Miller', email: 's.miller@quant.io', tier: 'Pro Trader', broker: 'IBKR', last: '2 mins ago' },
                { name: 'David Chen', email: 'david.c@wallstreet.com', tier: 'Institutional', broker: 'Alpaca', last: '14 mins ago' },
                { name: 'Marcus Aurelius', email: 'm.a@rome.it', tier: 'Explorer', broker: 'None', last: '1h ago' },
                { name: 'Elena Fisher', email: 'elena.f@uncharted.com', tier: 'Pro Trader', broker: 'Schwab', last: '5h ago' }
              ].map((user, i) => (
                <tr key={i} className="hover:bg-slate-800/30 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-[10px] text-indigo-400">{user.name[0]}</div>
                      <div>
                        <div className="text-sm font-bold text-white">{user.name}</div>
                        <div className="text-[10px] text-slate-500">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${user.tier === 'Institutional' ? 'bg-indigo-600/10 text-indigo-400' : user.tier === 'Pro Trader' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-800 text-slate-400'}`}>
                      {user.tier}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-xs text-slate-400 font-mono">{user.broker}</td>
                  <td className="px-6 py-4 text-xs text-slate-500">{user.last}</td>
                  <td className="px-6 py-4">
                    <button className="text-slate-600 hover:text-white group-hover:text-indigo-400 transition-colors">
                      <Settings size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-4xl">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">System Configuration</h2>
        <p className="text-slate-400">Modify global platform defaults, legal warnings, and API access keys.</p>
      </div>

      <div className="space-y-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-6 border-b border-slate-800 bg-slate-800/30">
            <h3 className="font-bold text-white flex items-center gap-2"><Lock size={18} className="text-indigo-400"/> Legal & Risk Compliance</h3>
          </div>
          <div className="p-6 space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">Global Risk Warning (Footer)</label>
                <span className="text-[10px] text-indigo-400 font-mono italic">Changes reflect globally on save</span>
              </div>
              <textarea 
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 min-h-[100px] focus:outline-none focus:border-indigo-500"
                value={riskWarning}
                onChange={(e) => setRiskWarning(e.target.value)}
              />
            </div>
            <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
              <div>
                <div className="text-sm font-bold text-white">Enable 2FA Enforcement</div>
                <div className="text-[10px] text-slate-500">Require all Institutional tier users to have MFA enabled.</div>
              </div>
              <div className="w-12 h-6 bg-indigo-600 rounded-full relative cursor-pointer">
                <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full shadow-lg"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-6 border-b border-slate-800 bg-slate-800/30">
            <h3 className="font-bold text-white flex items-center gap-2"><Zap size={18} className="text-amber-400"/> Platform Features</h3>
          </div>
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { label: 'Dark Mode (Default)', desc: 'Force institutional dark theme for all visitors.', active: true },
                { label: 'Live Data Polling', desc: 'Sync ticks every 100ms globally.', active: true },
                { label: 'Beta AI Models', desc: 'Enable experimental Llama-3 sentiment scoring.', active: false },
                { label: 'Paper Trading', desc: 'Allow simulation mode for Explorer tier.', active: true }
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 transition-colors cursor-pointer group">
                  <div className="max-w-[150px]">
                    <div className="text-xs font-bold text-white group-hover:text-indigo-400 transition-colors">{item.label}</div>
                    <div className="text-[10px] text-slate-500 leading-tight">{item.desc}</div>
                  </div>
                  <div className={`w-10 h-5 rounded-full relative transition-colors ${item.active ? 'bg-indigo-600' : 'bg-slate-800'}`}>
                    <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${item.active ? 'right-0.5' : 'left-0.5'}`}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <button className="px-6 py-3 rounded-xl text-slate-400 text-sm font-bold hover:bg-slate-900 transition-all">Cancel Changes</button>
          <button 
            onClick={handleSaveSettings}
            disabled={isSaving}
            className={`px-8 py-3 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center gap-2 ${isSaving ? 'opacity-70 animate-pulse' : ''}`}
          >
            {isSaving ? 'Saving...' : 'Save System Config'}
          </button>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard': return renderDashboard();
      case 'cms': return renderCMS();
      case 'subscriptions': return renderSubscriptions();
      case 'leads': return renderLeads();
      case 'settings': return renderSettings();
      default: return renderDashboard();
    }
  };

  const handleSearchResultClick = (type: 'view' | 'market' | 'news', id: string) => {
    setIsSearchFocused(false);
    setSearchQuery('');
    
    if (type === 'view') {
      setActiveView(id as AdminView);
    } else if (type === 'market') {
      setActiveView('dashboard');
      setTradeSymbol(id);
      setIsTradeModalOpen(true);
    } else if (type === 'news') {
      setActiveView('cms');
    }
  };

  return (
    <div className="flex h-screen bg-[#020617] text-slate-200 overflow-hidden font-inter relative">
      {showOnboarding && <OnboardingFlow onComplete={() => setShowOnboarding(false)} />}
      
      {/* Interaction Feedback Toast */}
      {showToast && (
        <div className="fixed bottom-8 right-8 z-[200] bg-indigo-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-right-10">
          <CheckCircle2 size={20} />
          <div className="font-bold text-sm">Action Successfully Synced!</div>
        </div>
      )}

      {/* Execution Modal */}
      {isTradeModalOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/30">
              <h3 className="font-bold text-white flex items-center gap-2"><Zap size={18} className="text-indigo-400"/> New Order Execution</h3>
              <button onClick={() => setIsTradeModalOpen(false)} className="text-slate-500 hover:text-white p-2">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleExecuteTrade} className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Ticker Symbol</label>
                  <select 
                    value={tradeSymbol}
                    onChange={(e) => setTradeSymbol(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-sm font-bold focus:outline-none focus:border-indigo-500 appearance-none"
                  >
                    {TICKER_DATA.map(s => <option key={s.symbol} value={s.symbol}>{s.symbol}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Order Side</label>
                  <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 h-[54px]">
                    <button 
                      type="button"
                      onClick={() => setTradeSide('BUY')}
                      className={`flex-1 rounded-lg text-xs font-bold transition-all ${tradeSide === 'BUY' ? 'bg-emerald-600 text-white' : 'text-slate-500 hover:text-white'}`}
                    >
                      BUY
                    </button>
                    <button 
                      type="button"
                      onClick={() => setTradeSide('SELL')}
                      className={`flex-1 rounded-lg text-xs font-bold transition-all ${tradeSide === 'SELL' ? 'bg-rose-600 text-white' : 'text-slate-500 hover:text-white'}`}
                    >
                      SELL
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Quantity</label>
                  <input 
                    type="number" 
                    value={tradeQty}
                    onChange={(e) => setTradeQty(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-sm font-bold focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Execution Price</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      readOnly 
                      value={`MKT (~$${(TICKER_DATA.find(s => s.symbol === tradeSymbol)?.price || 0).toFixed(2)})`}
                      className="w-full bg-slate-950/50 border border-slate-800 rounded-xl p-4 text-sm font-bold text-slate-400 focus:outline-none cursor-not-allowed"
                    />
                    <Lock size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600" />
                  </div>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="flex justify-between text-xs mb-2">
                  <span className="text-slate-500">Estimated Total</span>
                  <span className="text-white font-mono font-bold">
                    ${((TICKER_DATA.find(s => s.symbol === tradeSymbol)?.price || 0) * parseFloat(tradeQty || '0')).toLocaleString(undefined, {minimumFractionDigits: 2})}
                  </span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500">Margin Requirement</span>
                  <span className="text-white font-mono">None (Cash Account)</span>
                </div>
              </div>

              <button 
                type="submit"
                disabled={isSaving}
                className={`w-full py-5 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-xl ${
                  tradeSide === 'BUY' 
                    ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20' 
                    : 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/20'
                } ${isSaving ? 'opacity-70' : ''}`}
              >
                {isSaving ? <Loader2 className="animate-spin" /> : <>Confirm {tradeSide} Order <ArrowRight size={20}/></>}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <aside className={`bg-slate-950 border-r border-slate-900 flex flex-col transition-all duration-300 relative z-20 ${isSidebarCollapsed ? 'w-20' : 'w-72'}`}>
        <div className="p-6 flex items-center gap-3 border-b border-slate-900">
          <div className="bg-indigo-600 p-2 rounded-lg cursor-pointer" onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}>
            <TrendingUp className="text-white" size={20} />
          </div>
          {!isSidebarCollapsed && (
            <Link to="/" className="text-xl font-bold text-white tracking-tight hover:text-indigo-400 transition-colors">
              AlphaSight
            </Link>
          )}
        </div>

        <nav className="flex-grow p-4 space-y-2 overflow-y-auto scrollbar-hide">
          <div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest px-2 mb-4 whitespace-nowrap overflow-hidden">
            {isSidebarCollapsed ? 'PLAT' : 'Core Platform'}
          </div>
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id as AdminView)}
              className={`w-full flex items-center gap-4 px-3 py-3 rounded-xl transition-all ${activeView === item.id ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20' : 'text-slate-500 hover:text-white hover:bg-slate-900'}`}
              title={item.label}
            >
              <span className={activeView === item.id ? 'text-indigo-400' : ''}>{item.icon}</span>
              {!isSidebarCollapsed && <span className="font-medium text-sm">{item.label}</span>}
            </button>
          ))}
          
          {!isSidebarCollapsed && (
            <div className="pt-8">
              <div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest px-2 mb-4">Trading Status</div>
              <div className="space-y-4 px-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Live Engine</span>
                  <span className="flex items-center gap-2 text-emerald-500 font-bold">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Active
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">API Health</span>
                  <span className="text-emerald-500 font-bold">100%</span>
                </div>
              </div>
            </div>
          )}
        </nav>

        <div className="p-4 border-t border-slate-900">
          <button 
            onClick={() => navigate('/')}
            className="w-full flex items-center gap-4 px-3 py-3 rounded-xl text-rose-500 hover:bg-rose-500/10 transition-colors"
          >
            <Power size={20} />
            {!isSidebarCollapsed && <span className="font-medium text-sm">Disconnect</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-grow flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-slate-950/50 backdrop-blur-md border-b border-slate-900 flex items-center justify-between px-8 z-[60]">
          <div className="flex items-center gap-8 flex-grow relative" ref={searchRef}>
            <div className="relative max-w-md w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
              <input 
                type="text" 
                value={searchQuery}
                onFocus={() => setIsSearchFocused(true)}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search markets, news, or strategies..." 
                className="w-full bg-slate-900 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-white"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <Command size={12} className="text-slate-600" />
                <span className="text-[10px] font-bold text-slate-600">K</span>
              </div>
            </div>

            {/* Global Search Results Dropdown */}
            {isSearchFocused && searchQuery.trim() && (
              <div className="absolute top-full left-0 mt-2 w-full max-w-xl bg-slate-900/95 backdrop-blur-2xl border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200 z-[100]">
                <div className="max-h-[70vh] overflow-y-auto scrollbar-hide p-2">
                  {!hasAnyResults ? (
                    <div className="p-8 text-center">
                      <Search size={32} className="text-slate-700 mx-auto mb-3" />
                      <p className="text-sm text-slate-500">No matching signals found for "{searchQuery}"</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredResults.views.length > 0 && (
                        <div>
                          <div className="px-3 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800 mb-1">Platform Navigation</div>
                          {filteredResults.views.map(v => (
                            <button 
                              key={v.id}
                              onClick={() => handleSearchResultClick('view', v.id)}
                              className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-800 transition-colors text-left group"
                            >
                              <div className="flex items-center gap-3">
                                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg group-hover:scale-110 transition-transform">
                                  <Target size={14} />
                                </div>
                                <span className="text-sm font-bold text-white">{v.label}</span>
                              </div>
                              <ArrowRight size={14} className="text-slate-600 group-hover:text-indigo-400 translate-x-[-4px] group-hover:translate-x-0 transition-all" />
                            </button>
                          ))}
                        </div>
                      )}

                      {filteredResults.markets.length > 0 && (
                        <div>
                          <div className="px-3 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800 mb-1">Market Signals</div>
                          <div className="grid grid-cols-2 gap-1">
                            {filteredResults.markets.map(s => (
                              <button 
                                key={s.symbol}
                                onClick={() => handleSearchResultClick('market', s.symbol)}
                                className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-800 transition-colors text-left group"
                              >
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-bold text-white bg-slate-950 px-2 py-1 rounded">{s.symbol}</span>
                                  <span className={`text-[10px] font-bold ${s.change > 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                    {s.change > 0 ? '+' : ''}{s.changePercent}%
                                  </span>
                                </div>
                                <span className="text-[10px] text-slate-500 font-mono">${s.price.toFixed(2)}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {filteredResults.news.length > 0 && (
                        <div>
                          <div className="px-3 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800 mb-1">Intelligence Feed</div>
                          {filteredResults.news.map(a => (
                            <button 
                              key={a.id}
                              onClick={() => handleSearchResultClick('news', a.id)}
                              className="w-full p-3 rounded-xl hover:bg-slate-800 transition-colors text-left group"
                            >
                              <div className="text-[10px] text-indigo-400 font-bold mb-1">{a.category}</div>
                              <div className="text-xs font-medium text-slate-200 line-clamp-1">{a.title}</div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
                <div className="p-3 bg-slate-950/50 border-t border-slate-800 flex justify-between items-center text-[10px] text-slate-600">
                  <div className="flex gap-3">
                    <span className="flex items-center gap-1"><kbd className="bg-slate-800 px-1 rounded text-slate-400">↑↓</kbd> Select</span>
                    <span className="flex items-center gap-1"><kbd className="bg-slate-800 px-1 rounded text-slate-400">Enter</kbd> Open</span>
                  </div>
                  <span>AlphaSight Search Engine v2.5</span>
                </div>
              </div>
            )}
            
            <div className="flex items-center gap-6">
              {TICKER_DATA.slice(0, 3).map(stock => (
                <div key={stock.symbol} className="hidden xl:flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-400">{stock.symbol}</span>
                  <span className="text-sm font-mono text-white">${stock.price.toFixed(2)}</span>
                  <span className={`text-[10px] font-bold ${stock.change > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {stock.change > 0 ? '+' : ''}{stock.changePercent}%
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => { setTradeSide('BUY'); setIsTradeModalOpen(true); }}
              className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
            >
              <Plus size={18} /> New Trade
            </button>
            <div className="h-8 w-px bg-slate-800 mx-2"></div>
            <button className="relative p-2 text-slate-400 hover:text-white transition-colors">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full border-2 border-slate-950"></span>
            </button>
            
            <div className="relative" ref={profileRef}>
              <button 
                onClick={() => setIsProfileOpen(!isProfileOpen)}
                className="flex items-center gap-3 p-1 rounded-full border border-slate-800 bg-slate-900 pr-3 hover:border-slate-700 transition-all"
              >
                <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-bold text-white text-xs shadow-inner">JD</div>
                <span className="text-sm font-bold text-white hidden sm:block">John Doe</span>
                <ChevronDown size={14} className={`text-slate-500 transition-transform ${isProfileOpen ? 'rotate-180' : ''}`} />
              </button>

              {isProfileOpen && (
                <div className="absolute right-0 mt-3 w-56 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in zoom-in duration-200">
                  <div className="px-4 py-3 border-b border-slate-800">
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Account</p>
                    <p className="text-sm font-bold text-white truncate">j.doe@alphasight.ai</p>
                  </div>
                  <div className="p-2">
                    <button 
                      onClick={() => { setActiveView('settings'); setIsProfileOpen(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-sm"
                    >
                      <User size={16} /> My Profile
                    </button>
                    <button 
                      onClick={() => { setActiveView('subscriptions'); setIsProfileOpen(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-sm"
                    >
                      <CreditCard size={16} /> Billing & Tiers
                    </button>
                    <button 
                      onClick={() => { setActiveView('settings'); setIsProfileOpen(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-sm"
                    >
                      <Lock size={16} /> Security Settings
                    </button>
                  </div>
                  <div className="p-2 border-t border-slate-800">
                    <button 
                      onClick={() => navigate('/')}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-rose-500 hover:bg-rose-500/10 transition-colors text-sm font-bold"
                    >
                      <LogOut size={16} /> Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Dynamic Dashboard Content */}
        <div className="flex-grow p-8 overflow-y-auto scrollbar-hide bg-slate-950">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
