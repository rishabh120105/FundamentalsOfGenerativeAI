
import React, { useState } from 'react';
import { 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Wallet, 
  Cpu, 
  Bell, 
  CheckCircle2, 
  Activity
} from 'lucide-react';

interface OnboardingFlowProps {
  onComplete: () => void;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const totalSteps = 4;

  const steps = [
    {
      title: "Welcome to AlphaSight",
      description: "Let's set up your institutional trading environment in less than 2 minutes.",
      icon: <Activity className="w-12 h-12 text-indigo-500" />
    },
    {
      title: "Connect Your Broker",
      description: "Link your brokerage via secure OAuth. We support IBKR, Alpaca, and Schwab.",
      icon: <Wallet className="w-12 h-12 text-indigo-500" />
    },
    {
      title: "Deploy Your First Strategy",
      description: "Choose from our AI-optimized templates or build your own custom logic.",
      icon: <Cpu className="w-12 h-12 text-indigo-500" />
    },
    {
      title: "Activate Real-Time Alerts",
      description: "Get notified via SMS or Webhook when your entry criteria are met.",
      icon: <Bell className="w-12 h-12 text-indigo-500" />
    }
  ];

  const nextStep = () => {
    if (step < totalSteps) setStep(step + 1);
    else onComplete();
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/90 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl">
        <div className="relative p-8 text-center">
          <button 
            onClick={onComplete}
            className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>

          {/* Progress Bar */}
          <div className="flex gap-2 mb-10">
            {[...Array(totalSteps)].map((_, i) => (
              <div 
                key={i} 
                className={`h-1.5 flex-grow rounded-full transition-all duration-500 ${i + 1 <= step ? 'bg-indigo-500' : 'bg-slate-800'}`}
              />
            ))}
          </div>

          <div className="flex justify-center mb-6">
            <div className="p-4 bg-indigo-500/10 rounded-2xl animate-pulse">
              {steps[step - 1].icon}
            </div>
          </div>

          <h2 className="text-2xl font-bold text-white mb-3">{steps[step - 1].title}</h2>
          <p className="text-slate-400 mb-10 leading-relaxed">{steps[step - 1].description}</p>

          <div className="flex gap-4">
            {step > 1 && (
              <button 
                onClick={prevStep}
                className="flex-1 py-4 px-6 rounded-xl border border-slate-800 text-slate-300 font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
              >
                <ChevronLeft size={18} /> Back
              </button>
            )}
            <button 
              onClick={nextStep}
              className="flex-[2] py-4 px-6 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
            >
              {step === totalSteps ? 'Launch Dashboard' : 'Next Step'} <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingFlow;
