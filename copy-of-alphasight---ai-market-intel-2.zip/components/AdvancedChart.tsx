
import React, { useState, useMemo } from 'react';
import { 
  ComposedChart, 
  Area, 
  Line, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { 
  Settings2, 
  Maximize2, 
  MousePointer2, 
  Pencil, 
  Trash2, 
  BarChart2, 
  TrendingUp,
  Type
} from 'lucide-react';

const generateMockCandleData = (count: number) => {
  let basePrice = 500;
  return [...Array(count)].map((_, i) => {
    const open = basePrice + (Math.random() - 0.5) * 10;
    const close = open + (Math.random() - 0.5) * 15;
    const high = Math.max(open, close) + Math.random() * 5;
    const low = Math.min(open, close) - Math.random() * 5;
    basePrice = close;
    return {
      time: `${9 + Math.floor(i/12)}:${(i%12)*5 < 10 ? '0' : ''}${(i%12)*5}`,
      open, close, high, low,
      vol: Math.random() * 1000,
      ma20: basePrice - 2, // simplified MA
      ma50: basePrice - 5  // simplified MA
    };
  });
};

const AdvancedChart: React.FC = () => {
  const [data] = useState(generateMockCandleData(50));
  const [indicators, setIndicators] = useState({ ma20: true, ma50: false, volume: true });
  const [chartType, setChartType] = useState<'area' | 'bar'>('area');

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Chart Toolbar */}
      <div className="flex items-center justify-between p-3 border-b border-slate-800 bg-slate-800/30">
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button 
              onClick={() => setChartType('area')}
              className={`p-1.5 rounded ${chartType === 'area' ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <TrendingUp size={16} />
            </button>
            <button 
              onClick={() => setChartType('bar')}
              className={`p-1.5 rounded ${chartType === 'bar' ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <BarChart2 size={16} />
            </button>
          </div>
          
          <div className="h-6 w-px bg-slate-800 mx-1"></div>
          
          <div className="flex gap-1">
            <button 
              onClick={() => setIndicators(prev => ({ ...prev, ma20: !prev.ma20 }))}
              className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest border transition-all ${indicators.ma20 ? 'bg-indigo-500/20 border-indigo-500 text-indigo-400' : 'border-slate-800 text-slate-500'}`}
            >
              MA 20
            </button>
            <button 
              onClick={() => setIndicators(prev => ({ ...prev, ma50: !prev.ma50 }))}
              className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest border transition-all ${indicators.ma50 ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'border-slate-800 text-slate-500'}`}
            >
              MA 50
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="text-slate-500 hover:text-white p-1.5"><Pencil size={16} /></button>
          <button className="text-slate-500 hover:text-white p-1.5"><MousePointer2 size={16} /></button>
          <button className="text-slate-500 hover:text-white p-1.5"><Settings2 size={16} /></button>
          <button className="text-slate-500 hover:text-white p-1.5"><Maximize2 size={16} /></button>
        </div>
      </div>

      {/* Main Chart Area */}
      <div className="flex-grow min-h-[400px] w-full p-4">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis 
              dataKey="time" 
              stroke="#475569" 
              fontSize={10} 
              axisLine={false} 
              tickLine={false} 
              minTickGap={30}
            />
            <YAxis 
              stroke="#475569" 
              fontSize={10} 
              axisLine={false} 
              tickLine={false} 
              orientation="right"
              domain={['auto', 'auto']}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px', fontSize: '12px' }}
              itemStyle={{ color: '#fff' }}
              cursor={{ stroke: '#475569', strokeDasharray: '5 5' }}
            />
            
            {indicators.volume && (
              <Bar dataKey="vol" fill="#334155" opacity={0.3} yAxisId={0} />
            )}

            {chartType === 'area' ? (
              <Area 
                type="monotone" 
                dataKey="close" 
                stroke="#6366f1" 
                strokeWidth={2} 
                fillOpacity={1} 
                fill="url(#colorPrice)" 
              />
            ) : (
              <Bar dataKey="close" fill="#6366f1" radius={[2, 2, 0, 0]} />
            )}

            {indicators.ma20 && (
              <Line type="monotone" dataKey="ma20" stroke="#818cf8" dot={false} strokeWidth={1} />
            )}
            {indicators.ma50 && (
              <Line type="monotone" dataKey="ma50" stroke="#10b981" dot={false} strokeWidth={1} />
            )}

            <ReferenceLine y={data[data.length - 1].close} stroke="#f43f5e" strokeDasharray="3 3" label={{ value: `$${data[data.length - 1].close.toFixed(2)}`, fill: '#f43f5e', fontSize: 10, position: 'right' }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Legend / Info Bar */}
      <div className="bg-slate-950 p-2 px-4 border-t border-slate-800 flex items-center justify-between">
        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">RSI(14)</span>
            <span className="text-xs font-mono text-emerald-400">62.45</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">MACD(12,26,9)</span>
            <span className="text-xs font-mono text-white">0.45</span>
          </div>
        </div>
        <div className="text-[10px] text-slate-600 font-medium italic">Data synced from NASDAQ: L2 Provider</div>
      </div>
    </div>
  );
};

export default AdvancedChart;
