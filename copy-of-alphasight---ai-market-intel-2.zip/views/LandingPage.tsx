
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  BarChart3, 
  ShieldCheck, 
  CheckCircle2, 
  Globe, 
  Clock, 
  Award,
  ChevronRight,
  Play,
  X,
  Mail,
  Send,
  Loader2
} from 'lucide-react';
import { TICKER_DATA, FEATURES, PRICING_TIERS } from '../constants';
import MarketPreview from '../components/MarketPreview';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [showDemo, setShowDemo] = useState(false);
  const [showSales, setShowSales] = useState(false);
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubscribing(true);
    setTimeout(() => {
      setIsSubscribing(false);
      setSubscribed(true);
    }, 1500);
  };

  return (
    <div className="flex-grow overflow-x-hidden">
      {/* Ticker Tape */}
      <div className="bg-slate-900 border-y border-slate-800 overflow-hidden h-10 flex items-center relative z-10">
        <div className="ticker-scroll">
          {[...TICKER_DATA, ...TICKER_DATA].map((stock, i) => (
            <div key={`${stock.symbol}-${i}`} className="flex items-center space-x-2 px-6 whitespace-nowrap border-r border-slate-800 h-full">
              <span className="text-slate-400 font-bold text-xs">{stock.symbol}</span>
              <span className="text-white font-mono text-xs">${stock.price.toFixed(2)}</span>
              <span className={`text-[10px] font-bold ${stock.change > 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                {stock.change > 0 ? '+' : ''}{stock.changePercent}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Hero Section */}
      <header className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-[10%] right-[-5%] w-[30%] h-[30%] bg-emerald-600/10 blur-[100px] rounded-full"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-indigo-400 text-xs font-bold mb-8 animate-bounce">
            <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
            v2.5 Alpha Engine Now Live
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-tight">
            Institutional Intel for the <br />
            <span className="bg-gradient-to-r from-indigo-400 via-white to-emerald-400 bg-clip-text text-transparent">
              Modern Quant Trader
            </span>
          </h1>
          
          <p className="text-slate-400 text-lg md:text-xl max-w-3xl mx-auto mb-10 leading-relaxed">
            Unleash proprietary AI screeners, lightning-fast backtesting, and algorithmic execution. Stop guessing. Start analyzing with institutional-grade data.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <button 
              onClick={() => navigate('/login')}
              className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-xl shadow-indigo-600/30"
            >
              Start Analyzing Free <ArrowRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setShowDemo(true)}
              className="w-full sm:w-auto bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2"
            >
              <Play className="w-5 h-5 text-indigo-500" /> Watch Demo
            </button>
          </div>

          <div className="flex flex-wrap justify-center items-center gap-8 opacity-40 grayscale filter">
            <span className="text-xl font-bold">Bloomberg</span>
            <span className="text-xl font-bold italic underline">NASDAQ</span>
            <span className="text-xl font-serif font-bold italic">Financial Times</span>
            <span className="text-xl font-bold font-mono">CNBC</span>
            <span className="text-xl font-bold">REUTERS</span>
          </div>
        </div>
      </header>

      {/* Market Data Preview */}
      <MarketPreview />

      {/* Features Grid */}
      <section id="features" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {FEATURES.map((feature, i) => (
              <div key={i} className="group p-8 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition-all">
                <div className="bg-indigo-500/10 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-24 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-16">3 Steps to Market Alpha</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
            <div className="absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-transparent via-slate-800 to-transparent -z-10 hidden md:block"></div>
            
            {[
              { step: '01', title: 'Connect Broker', desc: 'Securely link your IBKR, Alpaca, or TD account via OAuth.', icon: <Globe className="w-6 h-6"/> },
              { step: '02', title: 'Set Strategy', desc: 'Use our AI wizard or PineScript logic to define signals.', icon: <BarChart3 className="w-6 h-6"/> },
              { step: '03', title: 'Automate', desc: 'Deploy with one click and monitor performance 24/7.', icon: <Clock className="w-6 h-6"/> }
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center text-indigo-500 font-bold text-xl mb-6 shadow-xl relative">
                  {item.icon}
                  <div className="absolute -top-2 -right-2 bg-indigo-600 text-white text-[10px] px-2 py-1 rounded-md">{item.step}</div>
                </div>
                <h4 className="text-xl font-bold text-white mb-2">{item.title}</h4>
                <p className="text-slate-400 text-sm max-w-xs mx-auto">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-24 border-y border-slate-900">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">The Edge Breakdown</h2>
          <div className="overflow-x-auto rounded-2xl border border-slate-800">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-900">
                  <th className="p-6 text-slate-400 font-bold uppercase text-xs">Capability</th>
                  <th className="p-6 text-indigo-400 font-bold uppercase text-xs">AlphaSight</th>
                  <th className="p-6 text-slate-500 font-bold uppercase text-xs">Trad. Brokers</th>
                  <th className="p-6 text-slate-500 font-bold uppercase text-xs">Terminals</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 bg-slate-950">
                {[
                  ['Tick Latency', '< 5ms', '500ms+', '10ms'],
                  ['AI Integration', 'Native Pro', 'None', 'Add-on ($$$)'],
                  ['Algo Execution', 'Zero-code', 'Manual/Complex', 'Scripts Only'],
                  ['Pricing', 'Affordable', 'Free*', 'High ($2k/mo)']
                ].map((row, i) => (
                  <tr key={i} className="hover:bg-white/5 transition-colors">
                    <td className="p-6 font-bold text-white text-sm">{row[0]}</td>
                    <td className="p-6 text-indigo-400 font-bold text-sm">{row[1]}</td>
                    <td className="p-6 text-slate-500 text-sm">{row[2]}</td>
                    <td className="p-6 text-slate-500 text-sm">{row[3]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Pricing Table */}
      <section id="pricing" className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Choose Your Precision</h2>
            <p className="text-slate-400">Scale from solo trader to institutional API access.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PRICING_TIERS.map((tier) => (
              <div key={tier.id} className={`p-8 rounded-3xl border ${tier.isPopular ? 'bg-slate-900 border-indigo-500 shadow-2xl shadow-indigo-500/10 scale-105 z-10' : 'bg-slate-900 border-slate-800'}`}>
                {tier.isPopular && <div className="text-indigo-400 text-[10px] font-bold uppercase tracking-widest mb-4">Most Recommended</div>}
                <h3 className="text-2xl font-bold text-white mb-2">{tier.name}</h3>
                <div className="flex items-baseline gap-2 mb-6">
                  <span className="text-4xl font-extrabold text-white">{tier.price}</span>
                  <span className="text-slate-400 text-sm">{tier.period}</span>
                </div>
                <ul className="space-y-4 mb-8">
                  {tier.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-3 text-slate-400 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0" /> {f}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => navigate('/login')}
                  className={`w-full py-4 rounded-xl font-bold transition-all ${tier.isPopular ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-slate-800 text-white hover:bg-slate-700'}`}
                >
                  Get Started
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lead Capture Newsletter */}
      <section className="py-24 bg-indigo-600 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-10">
          <Mail size={200} />
        </div>
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Morning Market Brief</h2>
          <p className="text-indigo-100 mb-10 opacity-80 max-w-xl mx-auto">Get high-conviction trade setups and AI sentiment summaries delivered to your inbox every morning before the opening bell.</p>
          
          {subscribed ? (
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-2xl animate-in zoom-in duration-300">
              <div className="flex items-center justify-center gap-2 text-white font-bold text-lg">
                <CheckCircle2 className="w-6 h-6 text-emerald-300" /> Subscription Confirmed!
              </div>
              <p className="text-indigo-100 text-sm mt-2">Check your email for the first brief.</p>
            </div>
          ) : (
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3">
              <input 
                type="email" 
                required
                placeholder="Enter your professional email" 
                className="flex-grow px-6 py-4 rounded-xl bg-white text-slate-900 font-medium focus:outline-none focus:ring-4 focus:ring-indigo-300/50 transition-all"
              />
              <button 
                disabled={isSubscribing}
                className="bg-slate-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2 min-w-[180px]"
              >
                {isSubscribing ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Subscribe Free <Send className="w-4 h-4"/></>}
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-24 bg-slate-950 border-t border-slate-900">
        <div className="max-w-7xl mx-auto px-4 flex flex-col items-center">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-white">Trusted by 12,000+ Quantitative Analysts</h2>
              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                  <div className="text-3xl font-bold text-indigo-400 mb-1">$4.2B+</div>
                  <div className="text-xs text-slate-500 uppercase tracking-widest font-bold">Trading Volume Managed</div>
                </div>
                <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
                  <div className="text-3xl font-bold text-emerald-400 mb-1">99.99%</div>
                  <div className="text-xs text-slate-500 uppercase tracking-widest font-bold">SLA Uptime Guarantee</div>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-slate-900 rounded-xl border border-slate-800">
                <Award className="w-10 h-10 text-amber-500" />
                <div>
                  <div className="font-bold text-white">#1 Trading Platform 2024</div>
                  <div className="text-xs text-slate-500">Awarded by Fintech Excellence Group</div>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 space-y-6">
              <div className="flex gap-1 text-amber-500">
                {[...Array(5)].map((_, i) => <span key={i}>★</span>)}
              </div>
              <p className="text-slate-300 italic leading-relaxed">
                "AlphaSight changed how I trade. I used to spend hours scanning manually. Now, my AI signals alert me before the move happens. It's essentially like having a junior analyst team working for me 24/7."
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center font-bold text-white">JS</div>
                <div>
                  <div className="font-bold text-white">James Sullivan</div>
                  <div className="text-xs text-slate-500">Professional Swing Trader</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 relative overflow-hidden bg-slate-950 border-t border-slate-900">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">Ready to capture Alpha?</h2>
          <p className="text-slate-400 text-lg mb-12">Join the top 1% of traders using algorithmic intelligence to beat the market. No credit card required for trial.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button 
              onClick={() => navigate('/login')}
              className="bg-indigo-600 text-white px-10 py-5 rounded-2xl font-bold text-xl hover:shadow-2xl hover:shadow-indigo-500/20 transition-all"
            >
              Claim Free Trial
            </button>
            <button 
              onClick={() => setShowSales(true)}
              className="bg-slate-900 text-white border border-slate-800 px-10 py-5 rounded-2xl font-bold text-xl hover:bg-slate-800"
            >
              Talk to Sales
            </button>
          </div>
        </div>
      </section>

      {/* Demo Modal */}
      {showDemo && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="relative w-full max-w-5xl aspect-video bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col items-center justify-center">
            <button 
              onClick={() => setShowDemo(false)}
              className="absolute top-6 right-6 p-2 bg-slate-950 rounded-full text-slate-500 hover:text-white transition-all z-10"
            >
              <X size={24} />
            </button>
            
            {/* Simulation of a video player */}
            <div className="w-full h-full flex items-center justify-center relative bg-black/40">
                <div className="text-center">
                    <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-indigo-600/40 cursor-pointer hover:scale-110 transition-transform">
                        <Play size={32} className="text-white ml-1" />
                    </div>
                    <h3 className="text-2xl font-bold text-white">Platform Demo v2.5</h3>
                    <p className="text-slate-400">Loading institutional data engine...</p>
                </div>
            </div>
          </div>
        </div>
      )}

      {/* Sales Lead Capture Modal */}
      {showSales && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl p-8">
            <button 
              onClick={() => setShowSales(false)}
              className="absolute top-6 right-6 p-2 text-slate-500 hover:text-white transition-all"
            >
              <X size={24} />
            </button>
            
            <h3 className="text-2xl font-bold text-white mb-2">Institutional Access</h3>
            <p className="text-slate-400 mb-8 text-sm">Schedule a consultation with our quant team to discuss high-volume API access and custom integrations.</p>
            
            <form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input type="text" placeholder="First Name" className="w-full bg-slate-950 border border-slate-800 p-4 rounded-xl text-sm focus:outline-none focus:border-indigo-500" />
                <input type="text" placeholder="Last Name" className="w-full bg-slate-950 border border-slate-800 p-4 rounded-xl text-sm focus:outline-none focus:border-indigo-500" />
              </div>
              <input type="email" placeholder="Work Email" className="w-full bg-slate-950 border border-slate-800 p-4 rounded-xl text-sm focus:outline-none focus:border-indigo-500" />
              <textarea placeholder="Tell us about your trading firm..." rows={3} className="w-full bg-slate-950 border border-slate-800 p-4 rounded-xl text-sm focus:outline-none focus:border-indigo-500" />
              <button 
                type="button"
                onClick={() => setShowSales(false)}
                className="w-full bg-indigo-600 text-white p-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
              >
                Send Request
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default LandingPage;
