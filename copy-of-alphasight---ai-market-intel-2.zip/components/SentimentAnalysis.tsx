
import React, { useState } from 'react';
import { 
  BrainCircuit, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Newspaper,
  Twitter,
  ExternalLink,
  Search,
  Globe,
  MessageSquare,
  Info,
  Loader2
} from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { NEWS_CMS_DATA } from '../constants';

interface Source {
  title: string;
  uri: string;
}

interface AnalysisResult {
  ticker: string;
  sentimentScore: number;
  summary: string;
  newsHeadlines: {
    headline: string;
    source: string;
    sentiment: 'positive' | 'negative' | 'neutral';
  }[];
  socialMentions: {
    text: string;
    platform: string;
  }[];
}

const SentimentAnalysis: React.FC = () => {
  const [analyzing, setAnalyzing] = useState(false);
  const [tickerInput, setTickerInput] = useState('');
  const [sources, setSources] = useState<Source[]>([]);
  const [detailedResult, setDetailedResult] = useState<AnalysisResult | null>(null);
  const [sentimentScores, setSentimentScores] = useState<Record<string, number>>({
    'SPY': 0.65,
    'NVDA': 0.82,
    'TSLA': -0.34,
    'AAPL': 0.12
  });

  const analyzeTicker = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const target = tickerInput.trim().toUpperCase() || 'SPY';
    setAnalyzing(true);
    setSources([]);
    setDetailedResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Conduct a deep sentiment analysis for the stock ticker: ${target}. 
        1. Search for the latest financial news (past 24h).
        2. Scan for social media sentiment and retail trader discussions.
        3. Provide a sentiment score from -1.0 to 1.0.
        4. List 3 key news headlines and 2 representative social media mentions.
        5. Summarize the overall consensus in one sentence.`,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              ticker: { type: Type.STRING },
              sentimentScore: { type: Type.NUMBER },
              summary: { type: Type.STRING },
              newsHeadlines: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    headline: { type: Type.STRING },
                    source: { type: Type.STRING },
                    sentiment: { type: Type.STRING }
                  },
                  required: ['headline', 'source', 'sentiment']
                }
              },
              socialMentions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    platform: { type: Type.STRING }
                  },
                  required: ['text', 'platform']
                }
              }
            },
            required: ['ticker', 'sentimentScore', 'summary', 'newsHeadlines', 'socialMentions'],
          }
        },
      });

      const text = response.text;
      if (text) {
        const result = JSON.parse(text.trim()) as AnalysisResult;
        setDetailedResult(result);
        setSentimentScores(prev => ({ ...prev, [result.ticker]: result.sentimentScore }));
      }

      // Extract Grounding Chunks
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const extractedSources: Source[] = chunks
          .filter((chunk: any) => chunk.web)
          .map((chunk: any) => ({
            title: chunk.web.title || 'Market Source',
            uri: chunk.web.uri
          }))
          .slice(0, 3);
        setSources(extractedSources);
      }
    } catch (error) {
      console.error("AI Analysis failed:", error);
    } finally {
      setAnalyzing(false);
    }
  };

  const getSentimentLabel = (score: number) => {
    if (score > 0.3) return { label: 'Strongly Positive', color: 'text-emerald-400', icon: <TrendingUp size={14}/>, bg: 'bg-emerald-500/10' };
    if (score > 0) return { label: 'Slightly Positive', color: 'text-emerald-300', icon: <TrendingUp size={14}/>, bg: 'bg-emerald-500/5' };
    if (score < -0.3) return { label: 'Strongly Negative', color: 'text-rose-400', icon: <TrendingDown size={14}/>, bg: 'bg-rose-500/10' };
    if (score < 0) return { label: 'Slightly Negative', color: 'text-rose-300', icon: <TrendingDown size={14}/>, bg: 'bg-rose-500/5' };
    return { label: 'Neutral', color: 'text-slate-400', icon: <Minus size={14}/>, bg: 'bg-slate-500/10' };
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <BrainCircuit className="text-indigo-500" />
          <h3 className="text-lg font-bold text-white">AI Sentiment</h3>
        </div>
      </div>

      <form onSubmit={analyzeTicker} className="mb-6 flex gap-2">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
          <input 
            type="text" 
            placeholder="Search Ticker (e.g. MSFT)" 
            value={tickerInput}
            onChange={(e) => setTickerInput(e.target.value.toUpperCase())}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 pl-9 pr-3 text-xs focus:outline-none focus:border-indigo-500 transition-all text-white font-mono"
          />
        </div>
        <button 
          type="submit"
          disabled={analyzing}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${analyzing ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/20'}`}
        >
          {analyzing ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
          Scan
        </button>
      </form>

      {detailedResult ? (
        <div className="flex-grow overflow-y-auto pr-2 space-y-6 hide-scrollbar animate-in fade-in slide-in-from-top-2 duration-500">
          {/* Detailed Card */}
          <div className={`p-4 rounded-xl border border-slate-800 ${getSentimentLabel(detailedResult.sentimentScore).bg}`}>
             <div className="flex justify-between items-center mb-3">
               <span className="text-xl font-mono font-bold text-white">{detailedResult.ticker}</span>
               <div className={`flex items-center gap-1 text-xs font-bold ${getSentimentLabel(detailedResult.sentimentScore).color}`}>
                 {getSentimentLabel(detailedResult.sentimentScore).icon}
                 {detailedResult.sentimentScore > 0 ? '+' : ''}{detailedResult.sentimentScore.toFixed(2)}
               </div>
             </div>
             <p className="text-xs text-slate-300 italic leading-relaxed">{detailedResult.summary}</p>
          </div>

          {/* News Contributing Section */}
          <div>
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
              <Newspaper size={12} className="text-indigo-400" /> News Catalysts
            </h4>
            <div className="space-y-2">
              {detailedResult.newsHeadlines.map((news, i) => (
                <div key={i} className="p-3 bg-slate-950 border border-slate-800 rounded-lg group">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[9px] font-bold text-slate-500 uppercase">{news.source}</span>
                    <span className={`text-[8px] font-bold uppercase px-1.5 py-0.5 rounded ${news.sentiment === 'positive' ? 'bg-emerald-500/10 text-emerald-500' : news.sentiment === 'negative' ? 'bg-rose-500/10 text-rose-500' : 'bg-slate-800 text-slate-400'}`}>
                      {news.sentiment}
                    </span>
                  </div>
                  <p className="text-[11px] font-medium text-slate-200 line-clamp-2">{news.headline}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Social Mentions */}
          <div>
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
              <Twitter size={12} className="text-sky-400" /> Social Buzz
            </h4>
            <div className="space-y-2">
              {detailedResult.socialMentions.map((mention, i) => (
                <div key={i} className="p-3 bg-slate-800/40 border border-slate-800 rounded-lg flex gap-3 items-start">
                  <div className="p-1.5 bg-slate-950 rounded-md shrink-0">
                    <MessageSquare size={10} className="text-slate-500" />
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-300 italic leading-snug">"{mention.text}"</p>
                    <div className="text-[9px] text-slate-600 mt-1 font-bold">via {mention.platform}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Grounded Citations */}
          {sources.length > 0 && (
            <div className="pt-4 border-t border-slate-800">
              <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                <Globe size={12} className="text-indigo-400" /> Sources
              </h4>
              <div className="space-y-2">
                {sources.map((source, i) => (
                  <a 
                    key={i} 
                    href={source.uri} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="flex items-center justify-between p-2 text-[10px] bg-indigo-500/5 border border-indigo-500/10 rounded hover:bg-indigo-500/10 transition-colors text-indigo-300"
                  >
                    <span className="truncate flex-grow">{source.title}</span>
                    <ExternalLink size={10} className="shrink-0 ml-2" />
                  </a>
                ))}
              </div>
            </div>
          )}
          
          <button 
            onClick={() => setDetailedResult(null)}
            className="w-full py-2 text-[10px] text-slate-500 font-bold hover:text-white transition-colors"
          >
            Clear Analysis
          </button>
        </div>
      ) : (
        <div className="flex-grow overflow-y-auto pr-2 space-y-4 hide-scrollbar">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 mb-2 text-center group relative overflow-hidden">
            <div className="absolute inset-0 bg-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">Live Market Pulse</div>
            <div className="text-3xl font-mono font-bold text-emerald-400">Bullish (0.58)</div>
            <div className="text-[11px] text-slate-400 mt-2">Real-time Cross-Source Analysis</div>
          </div>

          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
              <TrendingUp size={14} className="text-emerald-500" /> Watchlist Sentiment
            </h4>
            <div className="grid grid-cols-2 gap-3">
              {(Object.entries(sentimentScores) as [string, number][]).map(([ticker, score]) => (
                <div 
                  key={ticker} 
                  onClick={() => { setTickerInput(ticker); analyzeTicker(); }}
                  className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex flex-col gap-1 hover:border-indigo-500/50 cursor-pointer transition-all"
                >
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-white">{ticker}</span>
                    <div className={`text-[10px] font-mono font-bold ${score > 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                      {score > 0 ? '+' : ''}{score.toFixed(2)}
                    </div>
                  </div>
                  <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-1000 ${score > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`}
                      style={{ width: `${Math.abs(score) * 100}%`, marginLeft: score < 0 ? 'auto' : '0' }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Newspaper size={14} className="text-slate-400" /> Recent News
            </h4>
            {NEWS_CMS_DATA.map((news) => {
              const score = Math.random() * 2 - 1;
              const sent = getSentimentLabel(score);
              return (
                <div key={news.id} className="group p-4 mb-3 rounded-xl bg-slate-800/50 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-950 text-slate-400 uppercase tracking-wider">{news.category}</span>
                    <div className={`flex items-center gap-1 text-[10px] font-bold ${sent.color}`}>
                      {sent.icon} {sent.label}
                    </div>
                  </div>
                  <h4 className="text-sm font-semibold text-slate-200 group-hover:text-white transition-colors line-clamp-2 leading-snug">{news.title}</h4>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center gap-2 text-[10px] text-slate-500">
                      <Newspaper size={12}/> {news.author} • {news.timestamp}
                    </div>
                    <ExternalLink size={12} className="text-slate-600 group-hover:text-indigo-400 transition-colors"/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      
      {analyzing && (
        <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px] rounded-2xl flex items-center justify-center flex-col gap-3 z-50">
          <div className="relative">
            <Loader2 size={40} className="text-indigo-500 animate-spin" />
            <BrainCircuit size={20} className="absolute inset-0 m-auto text-white animate-pulse" />
          </div>
          <div className="text-xs font-bold text-white uppercase tracking-widest">Scanning Ticker {tickerInput || 'SPY'}...</div>
        </div>
      )}
    </div>
  );
};

export default SentimentAnalysis;
