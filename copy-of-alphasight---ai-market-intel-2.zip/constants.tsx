
import React from 'react';
import { StockData, NewsItem, SubscriptionTier } from './types';
import { 
  LineChart, 
  ShieldCheck, 
  Zap, 
  Cpu, 
  Layers, 
  Bell, 
  BarChart3, 
  Settings, 
  LayoutDashboard, 
  Users, 
  Newspaper, 
  CreditCard 
} from 'lucide-react';

export const TICKER_DATA: StockData[] = [
  { symbol: 'SPY', price: 502.12, change: 1.23, changePercent: 0.25, volume: '65M', marketCap: '450B' },
  { symbol: 'QQQ', price: 435.45, change: -2.15, changePercent: -0.49, volume: '42M', marketCap: '310B' },
  { symbol: 'NVDA', price: 822.79, change: 15.42, changePercent: 1.91, volume: '22M', marketCap: '2.1T' },
  { symbol: 'AAPL', price: 173.12, change: 0.88, changePercent: 0.51, volume: '51M', marketCap: '2.7T' },
  { symbol: 'TSLA', price: 168.45, change: -4.22, changePercent: -2.44, volume: '88M', marketCap: '540B' },
  { symbol: 'MSFT', price: 415.55, change: 3.10, changePercent: 0.75, volume: '18M', marketCap: '3.1T' },
  { symbol: 'BTC', price: 68422.10, change: 1205.40, changePercent: 1.79, volume: '34B', marketCap: '1.3T' },
];

export const FEATURES = [
  {
    title: 'Real-time Alerts',
    description: 'Ultra-low latency price and technical indicators alerts delivered via Webhook, SMS, or Email.',
    icon: <Bell className="w-6 h-6 text-indigo-400" />
  },
  {
    title: 'Backtesting Engine',
    description: 'Test strategies against 20 years of tick-level data with sub-millisecond precision.',
    icon: <Zap className="w-6 h-6 text-indigo-400" />
  },
  {
    title: 'AI Sentiment Analysis',
    description: 'Proprietary NLP models scanning millions of news sources and social data points every second.',
    icon: <Cpu className="w-6 h-6 text-indigo-400" />
  },
  {
    title: 'Multi-Broker Integration',
    description: 'Direct execution through Interactive Brokers, TD Ameritrade, and Alpaca.',
    icon: <Layers className="w-6 h-6 text-indigo-400" />
  }
];

export const PRICING_TIERS: SubscriptionTier[] = [
  {
    id: 'free',
    name: 'Explorer',
    price: '$0',
    period: 'forever',
    features: ['Delayed Market Data', '10 Active Alerts', 'Basic Screener', 'Standard Support'],
  },
  {
    id: 'pro',
    name: 'Pro Trader',
    price: '$49',
    period: 'per month',
    features: ['Real-time Nasdaq Data', 'Unlimited Alerts', 'Advanced AI Sentiment', 'Priority API Access', 'Backtesting Engine'],
    isPopular: true
  },
  {
    id: 'inst',
    name: 'Institutional',
    price: '$499',
    period: 'per month',
    features: ['Full Order Book Access', 'Dedicated Quants', 'Whitelabel Dashboard', 'SLA Guarantee', '99.9% Latency Match'],
  }
];

export const NEWS_CMS_DATA: NewsItem[] = [
  {
    id: '1',
    title: 'Federal Reserve Signals Potential Rate Cut in Q3',
    category: 'Macro',
    timestamp: '2h ago',
    author: 'Alpha Team',
    summary: 'Powell suggests inflation data is moving in the right direction but emphasizes caution.'
  },
  {
    id: '2',
    title: 'AI Sector Performance Surpasses Estimates',
    category: 'Tech',
    timestamp: '5h ago',
    author: 'Quant Analyst',
    summary: 'Cloud infrastructure providers see 15% revenue growth attributed to generative AI workloads.'
  }
];
