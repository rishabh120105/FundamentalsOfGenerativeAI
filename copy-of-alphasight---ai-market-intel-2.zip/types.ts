
export interface StockData {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: string;
  marketCap: string;
  sentiment?: number; // -1 to 1
}

export interface NewsItem {
  id: string;
  title: string;
  category: 'Market' | 'Tech' | 'Crypto' | 'Macro';
  timestamp: string;
  author: string;
  summary: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
  sentimentScore?: number;
}

export interface SubscriptionTier {
  id: string;
  name: string;
  price: string;
  period: string;
  features: string[];
  isPopular?: boolean;
}

export type AdminView = 'dashboard' | 'cms' | 'subscriptions' | 'leads' | 'settings';

export interface OnboardingState {
  step: number;
  completed: boolean;
  brokerConnected: boolean;
  strategyCreated: boolean;
}
