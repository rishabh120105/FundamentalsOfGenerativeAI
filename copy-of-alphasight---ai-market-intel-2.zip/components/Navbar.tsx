
import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { LineChart, Menu, X, User } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const scrollToSection = (id: string) => {
    setIsOpen(false);
    if (location.pathname !== '/') {
      navigate('/');
      // Delay to allow navigation to complete before scrolling
      setTimeout(() => {
        const el = document.getElementById(id);
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <LineChart className="w-8 h-8 text-indigo-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
                AlphaSight
              </span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <button onClick={() => scrollToSection('features')} className="text-slate-300 hover:text-white transition-colors text-sm font-medium">Features</button>
            <button onClick={() => scrollToSection('market')} className="text-slate-300 hover:text-white transition-colors text-sm font-medium">Market</button>
            <button onClick={() => scrollToSection('pricing')} className="text-slate-300 hover:text-white transition-colors text-sm font-medium">Pricing</button>
            
            <div className="h-6 w-px bg-slate-800 mx-2"></div>
            
            <Link to="/login" className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors text-sm font-medium">
              <User size={16} className="text-slate-500" />
              Login
            </Link>
            
            <button 
              onClick={() => navigate('/login')}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg font-semibold transition-all shadow-lg shadow-indigo-500/20 text-sm"
            >
              Get Started
            </button>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-300">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 p-4 space-y-4">
          <button onClick={() => scrollToSection('features')} className="block w-full text-left text-slate-300 py-2">Features</button>
          <button onClick={() => scrollToSection('market')} className="block w-full text-left text-slate-300 py-2">Market</button>
          <button onClick={() => scrollToSection('pricing')} className="block w-full text-left text-slate-300 py-2">Pricing</button>
          <Link to="/login" className="block text-slate-300 py-2 font-medium" onClick={() => setIsOpen(false)}>Login</Link>
          <button 
            onClick={() => { navigate('/login'); setIsOpen(false); }}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold"
          >
            Get Started
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
