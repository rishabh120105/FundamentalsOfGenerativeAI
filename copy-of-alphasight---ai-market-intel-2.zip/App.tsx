
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './views/LandingPage';
import AdminDashboard from './views/AdminDashboard';
import LoginPage from './views/LoginPage';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Routes>
          {/* Landing Page Route with Layout */}
          <Route path="/" element={
            <>
              <Navbar />
              <LandingPage />
              <Footer />
            </>
          } />
          
          {/* Auth Route */}
          <Route path="/login" element={<LoginPage />} />
          
          {/* Admin Dashboard Routes - No standard Navbar/Footer */}
          <Route path="/admin/*" element={<AdminDashboard />} />
          
          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
