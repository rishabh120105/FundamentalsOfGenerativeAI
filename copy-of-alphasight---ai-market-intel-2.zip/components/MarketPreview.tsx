
import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TICKER_DATA } from '../constants';
import { TrendingUp, TrendingDown, BrainCircuit } from 'lucide-react';

const mockChartData = [
  { time: '09:30', price: 498.2 },
  { time: '10:00', price: 501.1 },
  { time: '10:30', price: 500.5 },
  { time: '11:00', price: 502.8 },
  { time: '11:30', price: 504.2 },
  { time: '12:00', price: 503.1 },
  { time: '12:30', price: 505.5 },
  { time: '13:00', price: 506.8 },
  { time: '13:30', price: 508.4 },
];

const MarketPreview: React.FC = () => {
  const [activeInterval, setActiveInterval] = useState('1D');

  return (
    <section id="market" className="py-24 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Market Intelligence Dashboard</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Experience zero-latency data visualization. Our proprietary engine processes 4M+ ticks per second for institutional accuracy.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Heatmap/List */}
          <div className="lg:col-span-1 bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 bg-slate-800/50 flex justify-between items-center">
              <span className="font-bold text-sm uppercase tracking-wider text-slate-400">Live AI Screener</span>
              <span className="text-xs text-emerald-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Live
              </span>
            </div>
            <div className="divide-y divide-slate-800">
              {TICKER_DATA.map((stock) => {
                const isBullish = stock.change > 0;
                return (
                  <div key={stock.symbol} className="p-4 hover:bg-slate-800/50 transition-colors flex justify-between items-center cursor-pointer group">
                    <div className="flex items-center gap-3">
                      <div className={`p-1 rounded-md transition-all group-hover:scale-110 ${isBullish ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                        <BrainCircuit size={14} />
                      </div>
                      <div>
                        <div className="font-bold text-white text-sm">{stock.symbol}</div>
                        <div className="text-[10px] text-slate-500">{stock.marketCap}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-medium text-sm">${stock.price.toFixed(2)}</div>
                      <div className={`text-xs flex items-center justify-end gap-1 ${stock.change > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {stock.change > 0 ? <TrendingUp size={12}/> : <TrendingDown size={12}/>}
                        {stock.changePercent}%
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Chart View */}
          <div className="lg:col-span-2 bg-slate-900 rounded-2xl border border-slate-800 p-6 flex flex-col shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-4">
                <div className="bg-indigo-500/10 p-2 rounded-lg text-indigo-400 font-bold">SPY</div>
                <div>
                  <div className="text-lg font-bold text-white">$502.12</div>
                  <div className="text-xs text-slate-500">S&P 500 ETF Trust</div>
                </div>
              </div>
              <div className="flex gap-2 bg-slate-950 p-1 rounded-lg border border-slate-800">
                {['1M', '5M', '15M', '1H', '1D'].map(t => (
                  <button 
                    key={t} 
                    onClick={() => setActiveInterval(t)}
                    className={`px-3 py-1 rounded text-[10px] font-bold transition-all ${t === activeInterval ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex-grow h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockChartData}>
                  <defs>
                    <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="time" stroke="#475569" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis stroke="#475569" fontSize={10} axisLine={false} tickLine={false} domain={['dataMin - 2', 'dataMax + 2']} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                    itemStyle={{ color: '#fff' }}
                  />
                  <Area type="monotone" dataKey="price" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorPrice)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-6 flex justify-around border-t border-slate-800 pt-6">
              {[
                { label: 'RSI(14)', val: '58.2', status: 'Neutral' },
                { label: 'MACD', val: '2.14', status: 'Bullish' },
                { label: 'AI Mood', val: '0.85', status: 'Strong Buy' }
              ].map(stat => (
                <div key={stat.label} className="text-center">
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest">{stat.label}</div>
                  <div className="font-mono text-white font-medium">{stat.val}</div>
                  <div className={`text-[10px] font-bold ${stat.status === 'Bullish' || stat.status === 'Strong Buy' ? 'text-emerald-500' : 'text-slate-400'}`}>{stat.status}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MarketPreview;
