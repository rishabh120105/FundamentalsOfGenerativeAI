
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  LineChart, 
  Lock, 
  Mail, 
  ArrowRight, 
  ShieldCheck, 
  Github, 
  Chrome, 
  Loader2,
  ChevronLeft,
  Eye,
  EyeOff,
  AlertCircle
} from 'lucide-react';

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Institutional Handshake Simulation
    setTimeout(() => {
      // Allow any credentials for the demo, but check for specific one to show "Premium" state
      const isInstitutional = password === 'ALPHA-2025-VEO';
      
      setIsLoading(false);
      navigate('/admin');
    }, 1800);
  };

  return (
    <div className="min-h-screen bg-[#020617] flex flex-col items-center justify-center p-4 relative overflow-hidden font-inter">
      {/* Background Decorative Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/10 blur-[120px] rounded-full"></div>
      <div className="absolute bottom-[10%] right-[-5%] w-[30%] h-[30%] bg-emerald-600/5 blur-[100px] rounded-full"></div>
      
      {/* Back to Home */}
      <Link 
        to="/" 
        className="absolute top-8 left-8 flex items-center gap-2 text-slate-500 hover:text-white transition-colors text-sm font-medium group z-50"
      >
        <ChevronLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
        Back to AlphaSight
      </Link>

      <div className="w-full max-w-md animate-in fade-in zoom-in duration-500 relative z-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <LineChart className="w-10 h-10 text-indigo-500" />
            <span className="text-3xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
              AlphaSight
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white">Institutional Portal</h1>
          <p className="text-slate-500 text-sm mt-2">Access your high-frequency trading environment</p>
        </div>

        <div className="bg-slate-900/40 backdrop-blur-2xl border border-slate-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
          {/* Security Banner */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-emerald-500 to-indigo-500 animate-pulse"></div>

          {error && (
            <div className="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center gap-3 text-rose-400 text-xs animate-in slide-in-from-top-2">
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 px-1">Institutional Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@alphasight.ai"
                  className="w-full bg-slate-950/50 border border-slate-800 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-sm"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2 px-1">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">Access Key</label>
                <button type="button" className="text-[10px] font-bold text-indigo-400 hover:underline">Forgot Password?</button>
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                <input 
                  type={showPassword ? "text" : "password"} 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="ALPHA-2025-VEO"
                  className="w-full bg-slate-950/50 border border-slate-800 rounded-xl py-4 pl-12 pr-12 text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-sm font-mono"
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 px-1">
              <input 
                type="checkbox" 
                id="remember"
                className="w-4 h-4 rounded border-slate-800 bg-slate-950 text-indigo-600 focus:ring-indigo-500"
              />
              <label htmlFor="remember" className="text-xs text-slate-400">Secure this workstation for 30 days</label>
            </div>

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-600/20 group disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="flex items-center gap-3">
                  <Loader2 className="animate-spin" size={20} />
                  <span>Verifying Handshake...</span>
                </div>
              ) : (
                <>Sign In to AlphaSight <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" /></>
              )}
            </button>
          </form>

          <div className="relative my-8 text-center">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-800"></div></div>
            <span className="relative bg-[#0d1526] px-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Authorized Single Sign-On</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-2 bg-slate-950/50 border border-slate-800 hover:border-slate-700 py-3 rounded-xl transition-all text-xs font-bold text-slate-300">
              <Chrome size={16} /> Google
            </button>
            <button className="flex items-center justify-center gap-2 bg-slate-950/50 border border-slate-800 hover:border-slate-700 py-3 rounded-xl transition-all text-xs font-bold text-slate-300">
              <Github size={16} /> GitHub
            </button>
          </div>
        </div>

        <div className="mt-8 p-4 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl">
          <p className="text-slate-500 text-xs text-center">
            <span className="font-bold text-indigo-400">Demo Mode:</span> Use <code className="bg-slate-950 px-1 py-0.5 rounded text-indigo-300">ALPHA-2025-VEO</code> for full institutional access.
          </p>
        </div>

        <div className="mt-12 flex items-center justify-center gap-4 opacity-30">
          <div className="flex items-center gap-1.5 grayscale">
            <ShieldCheck size={14} className="text-emerald-500" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-white">SOC2 Level 3</span>
          </div>
          <div className="w-1 h-1 bg-slate-800 rounded-full"></div>
          <div className="flex items-center gap-1.5 grayscale">
            <Lock size={14} className="text-indigo-500" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-white">256-bit AES</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
